/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// JSExLink.js
window.onload = init;
function init() {
  document.getElementById("myLink").onclick = showWarning;
}
function showWarning() {
  return confirm("Warning! Proceed with care!");
}