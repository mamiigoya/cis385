/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


// JSExFiles.js
window.onload = function() {
init();
   alert("Hello!");
};
function init() {
   document.getElementById("magic").onmouseover = function() {
      this.className = "highlight";
   };
   document.getElementById("magic").onmouseout = function() {
      this.className = "";
}; }